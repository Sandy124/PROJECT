package com.capgemini.salesmanagement.tests;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exceptions.InvalidSaleIdException;
import com.capgemini.salesmanagement.service.SaleService;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class SaleServiceTest {

	private static SaleService service;
	private static Sale sale;
	@BeforeClass
	public static void setUpTestEnv() {
		service = new SaleService();
	}
	
	@Before
	public void setUpTestData() {
		Sale sale = new Sale(1001, "SmartPhone", "Electronics", CollectionUtil.currDate(), 2, 2*35000, "iPhone");
		CollectionUtil.sales.put(sale.getSaleId(), sale);
		
	}
	
	@Test(expected = InvalidSaleIdException.class)
	public void testForInvalidSaleId() throws InvalidSaleIdException {
		service.getSaleDetails(5690);
	}
	
	@Test
	public void testForValidSaleId() {
		Sale sale = new Sale(1001, "SmartPhone", "Electronics", CollectionUtil.currDate(), 2, 2*35000, "iPhone");
		HashMap<Integer, Sale> map =  service.insertSalesDetails(sale);
		boolean actualId =map.containsKey(sale.getSaleId());
		
		Assert.assertEquals(true, actualId);
	}
	
	@After
	public void tearDownTestData() {
		CollectionUtil.sales.clear();
	}
	@AfterClass
	public static void tearDownTestEnv() {
		service = null;
	}
	

}
