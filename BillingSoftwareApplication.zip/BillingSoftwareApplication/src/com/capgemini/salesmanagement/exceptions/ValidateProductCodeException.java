package com.capgemini.salesmanagement.exceptions;

public class ValidateProductCodeException extends Exception {

	public ValidateProductCodeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ValidateProductCodeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ValidateProductCodeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ValidateProductCodeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ValidateProductCodeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
