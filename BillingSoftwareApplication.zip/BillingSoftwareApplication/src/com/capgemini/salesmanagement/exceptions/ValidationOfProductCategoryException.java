package com.capgemini.salesmanagement.exceptions;

public class ValidationOfProductCategoryException extends Exception{

	public ValidationOfProductCategoryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ValidationOfProductCategoryException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ValidationOfProductCategoryException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ValidationOfProductCategoryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ValidationOfProductCategoryException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
