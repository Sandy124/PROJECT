package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InvalidSaleIdException;
import com.capgemini.salesmanagement.exceptions.ValidateProductCodeException;
import com.capgemini.salesmanagement.exceptions.ValidateProductNameException;
import com.capgemini.salesmanagement.exceptions.ValidateProductPriceException;
import com.capgemini.salesmanagement.exceptions.ValidationOfProductCategoryException;
import com.capgemini.salesmanagement.exceptions.ValidationOfQuantityException;

public interface ISaleService {
	public HashMap<Integer, Sale>  insertSalesDetails(Sale sale);
	public boolean validateProductCode(int productId) throws ValidateProductCodeException ;
	boolean validateQuantity(int qty) throws ValidationOfQuantityException;
	public boolean validateProductCat(String prodCat) throws ValidationOfProductCategoryException;
	public boolean validateProductName(String prodName) throws ValidateProductNameException;
	public boolean validateProductPrice(float price)  throws ValidateProductPriceException;
	public Sale getSaleDetails(int saleId) throws InvalidSaleIdException;
}
