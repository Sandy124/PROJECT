package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exceptions.InvalidSaleIdException;
import com.capgemini.salesmanagement.exceptions.ValidateProductCodeException;
import com.capgemini.salesmanagement.exceptions.ValidateProductNameException;
import com.capgemini.salesmanagement.exceptions.ValidateProductPriceException;
import com.capgemini.salesmanagement.exceptions.ValidationOfProductCategoryException;
import com.capgemini.salesmanagement.exceptions.ValidationOfQuantityException;

public class SaleService implements ISaleService {

	ISaleDAO serviceDao = new SaleDAO();
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		// TODO Auto-generated method stub
		return serviceDao.insertSalesDetails(sale);
	}

	@Override
	public boolean validateProductCode(int productId) throws ValidateProductCodeException {
		// TODO Auto-generated method stub
		if(productId == 1001 || productId == 1002 || productId == 1003 || productId == 1004)
			return true;
		else
			throw new ValidateProductCodeException("Invalid Product Code");
	}

	@Override
	public boolean validateQuantity(int qty) throws ValidationOfQuantityException {
		// TODO Auto-generated method stub
		if(qty > 0 && qty < 5)
			return true;
		throw new ValidationOfQuantityException("Invalid Product Quantity");
		
	}

	@Override
	public boolean validateProductCat(String prodCat) throws ValidationOfProductCategoryException {
		// TODO Auto-generated method stub
		if(prodCat.equals("Electronics") || prodCat.equals("Toys"))
			return true;
		else
			throw new ValidationOfProductCategoryException("Invalid Product Category");
	}

	@Override
	public boolean validateProductName(String prodName) throws ValidateProductNameException {
		// TODO Auto-generated method stub
		if(prodName.equals("TV") || prodName.equals("SmartPhone") || prodName.equals("VideoGame") || prodName.equals("SoftToy") || 
				prodName.equals("Telescope") || prodName.equals("BarbeeDoll"))
			return true;
		else
			throw new ValidateProductNameException("Invalid Product");
	}

	@Override
	public boolean validateProductPrice(float price) throws ValidateProductPriceException {
		// TODO Auto-generated method stub
		if(price > 200)
			return true;
		throw new ValidateProductPriceException("Invalid product Price");
		
	}

	@Override
	public Sale getSaleDetails(int saleId) throws InvalidSaleIdException {
		// TODO Auto-generated method stub
		Sale sale = serviceDao.findOne(saleId);
		if(sale == null)
			throw new InvalidSaleIdException("Invalid Sale Id");
		return sale;
	}

}
