package com.capgemini.salesmanagement.ui;

import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InvalidSaleIdException;
import com.capgemini.salesmanagement.exceptions.ValidateProductCodeException;
import com.capgemini.salesmanagement.exceptions.ValidateProductNameException;
import com.capgemini.salesmanagement.exceptions.ValidateProductPriceException;
import com.capgemini.salesmanagement.exceptions.ValidationOfProductCategoryException;
import com.capgemini.salesmanagement.exceptions.ValidationOfQuantityException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ISaleService service = new SaleService();
		int productCode = 0;
		int quantity = 0;
		String prodCat = null;
		String prodName = null;
		String prodPar = null;
		float prodPrice;
		float lineTotal = 0;
		Scanner sc= new Scanner(System.in);
		
		try {
			System.out.println("Enter Product code :");
			productCode = sc.nextInt();
			if(service.validateProductCode(productCode))
			
			System.out.println("Enter the quantity :");
			quantity = sc.nextInt();
			if(service.validateQuantity(quantity))
			
			System.out.println("Enter the product category : ");
			prodCat = sc.next();
			if(service.validateProductCat(prodCat))
			
			System.out.println("Enter product Description :");
			prodName = sc.next();
			if(service.validateProductName(prodName));
		
			//this method is done for the input of specific product name i.e iPhone in this case
			System.out.println("Enter Particular Product Name");
			prodPar = sc.next();
			
			System.out.println("Enter product price :");
			prodPrice = sc.nextFloat();
			if(service.validateProductPrice(prodPrice));
			lineTotal = quantity * prodPrice;
			System.out.println("The Line Total is :"+lineTotal);
			
		} catch (ValidateProductCodeException e ) {
			
			e.printStackTrace();
		} catch (ValidationOfQuantityException e) {
			
			e.printStackTrace();
		} catch (ValidationOfProductCategoryException e) {
			
			e.printStackTrace();
		} catch (ValidateProductNameException e) {
			
			e.printStackTrace();
		} catch (ValidateProductPriceException e) {
			
			e.printStackTrace();
		}
		Sale sale = new Sale(productCode, prodName, prodCat, CollectionUtil.currDate(), quantity, lineTotal, prodPar);
		HashMap<Integer, Sale> salesMap = service.insertSalesDetails(sale);
		for (Integer i : salesMap.keySet()) {
			System.out.println("Sales Details :" + salesMap.get(i));
		}
		System.out.println("Fetching sales details when the saleid " +sale.getSaleId() + "  is provided :");
		try {
			System.out.println(service.getSaleDetails(sale.getSaleId()));
		} catch (InvalidSaleIdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
