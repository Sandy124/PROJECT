package com.capgemini.salesmanagement.dao;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class SaleDAO implements ISaleDAO {

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		// TODO Auto-generated method stub
		sale.setSaleId(CollectionUtil.getSALE_ID());
		sale.setSaleDate(CollectionUtil.currDate());
		CollectionUtil.sales.put(sale.getSaleId(), sale);
		return CollectionUtil.getCollection();
	}

	@Override
	public Sale findOne(int saleId) {
		// TODO Auto-generated method stub
		return CollectionUtil.sales.get(saleId);
	}

}
